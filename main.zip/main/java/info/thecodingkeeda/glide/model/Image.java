package info.thecodingkeeda.glide.model;

import java.io.Serializable;

public class Image implements Serializable{

    private String farmId;
    private String serverId, photoId, size;
    private String secret;

    public String getFinalURl() {
        return finalURl;
    }

    public void setFinalURl(String finalURl) {
        this.finalURl = finalURl;
    }

    private String finalURl;

    public Image() {
    }

    public String getFarmId() {
        return farmId;
    }

    public void setFarmId(String farmId) {
        this.farmId = farmId;
    }

    public String getServerId() {
        return serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String getPhotoId() {
        return photoId;
    }

    public void setPhotoId(String photoId) {
        this.photoId = photoId;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }




}
