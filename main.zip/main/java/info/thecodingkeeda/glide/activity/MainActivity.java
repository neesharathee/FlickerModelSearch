package info.thecodingkeeda.glide.activity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import info.thecodingkeeda.glide.R;
import info.thecodingkeeda.glide.adapter.GalleryAdapter;
import info.thecodingkeeda.glide.app.AppController;
import info.thecodingkeeda.glide.model.Image;

import static com.android.volley.Request.*;

public class MainActivity extends AppCompatActivity {

    private  final String TAG = MainActivity.class.getSimpleName();
    private  String FlickrQuery_url = "https://api.flickr.com/services/rest/?method=flickr.photos.search";
    private  String FlickrQuery_per_page = "&per_page=10";
    public static final int PAGE_SIZE = 10;
    private  String FlickrQuery_page = "&page=2";
    private  String FlickrQuery_nojsoncallback = "&nojsoncallback=1";
    private  String FlickrQuery_format = "&format=json";
    private  String FlickrQuery_tag = "&tags=";
    private  String FlickrQuery_key = "&api_key=";
    private  String SearchItem;
    private  String FlickrApiKey = "208c5091e529e7aac9ddfa176288e805";


    int visibleItemCount, totalItemCount;

    private ArrayList<Image> images;
    private ProgressDialog pDialog;
    private GalleryAdapter mAdapter;
    private RecyclerView recyclerView;
    private EditText mEditText;
    private Button mButton;
    private String endpoint;
    StaggeredGridLayoutManager mLayoutManager;
   // ArrayList<String> temp;
   // private AppDatabase mAppDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SearchItem = mEditText.getText().toString();
                endpoint = FlickrQuery_url + FlickrQuery_key + FlickrApiKey+ FlickrQuery_tag + SearchItem+ FlickrQuery_per_page+ FlickrQuery_page+ FlickrQuery_format+ FlickrQuery_nojsoncallback ;
                fetchImages();
//                if(!isNetworkAvailable())
//                {  final Image image=new Image();
//                    new Thread(new Runnable() {
//                        @Override
//                        public void run() {
//                            List<String> temp = DbUtil.getImageDataFromDb(SearchItem);
//                            for (int i=0; i<temp.size(); i++)
//                                image.setFinalURl(temp.get(i));
//                            images.add(image);
//                        }
//                    }).start();
//                    closeKeyboard();
//                }
//                else   {

                    //closeKeyboard();
//                }


            }
        });


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mEditText=(EditText) findViewById(R.id.search_string);
        mButton=(Button)findViewById(R.id.button_send);

        images = new ArrayList<>();
      //  mAppDatabase=AppController.getDatabase();
        mAdapter = new GalleryAdapter(getApplicationContext(), images);
        pDialog = new ProgressDialog(this);
         mLayoutManager = new StaggeredGridLayoutManager(2, 1);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if(dy > 0)
                {
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    int[] firstVisibleItemPositions = mLayoutManager.findFirstVisibleItemPositions(null);
                    if ((visibleItemCount + firstVisibleItemPositions[0]) >= totalItemCount
                       && firstVisibleItemPositions[0] >= 0 && totalItemCount >= PAGE_SIZE){
                        fetchImages();

                    }

                }
            }
        });

        recyclerView.addOnItemTouchListener(new GalleryAdapter.RecyclerTouchListener(getApplicationContext(), recyclerView, new GalleryAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("images", images);
                bundle.putInt("position", position);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                SlideshowDialogFragment newFragment = SlideshowDialogFragment.newInstance();
                newFragment.setArguments(bundle);
                newFragment.show(ft, "slideshow");
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }



   // private void closeKeyboard() {
//        InputMethodManager inputManager = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
//        inputManager.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
//
//    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.action_settings) {
            mLayoutManager.setSpanCount(2);
            return true;
        }
        if (id == R.id.row3) {
            mLayoutManager.setSpanCount(3);
            return true;
        }
        if (id == R.id.row4) {
            mLayoutManager.setSpanCount(4);
            return true;
        }

        Log.d(TAG, "onOptionsItemSelected returned : returned");
        return super.onOptionsItemSelected(item);
    }

    private void fetchImages() {

        pDialog.setMessage("Hang on a sec...");
        pDialog.show();
JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Method.GET, endpoint, null, new Response.Listener<JSONObject>() {
    @Override
    public void onResponse(JSONObject response) {
        Log.d(TAG, response.toString());
                       pDialog.hide();
//temp=new ArrayList<>();
                       images.clear();
                            try {
                                JSONObject object = response.getJSONObject("photos");
                                JSONArray jsonArray = object.getJSONArray("photo");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject param = jsonArray.getJSONObject(i);
                                    final Image image = new Image();
                                    String farmId = param.getString("farm");
                                    String serverId = param.getString("server");
                                    String photoId = param.getString("id");
                                    String secret = param.getString("secret");
                                    String URL = "https://farm" + farmId + ".staticflickr.com/" + serverId + "/" + photoId + "_" + secret + "_q.jpg";
                                    image.setFarmId(farmId);
                                    image.setServerId(serverId);
                                    image.setPhotoId(photoId);
                                    image.setSecret(secret);
                                    image.setFinalURl(URL);
                                    images.add(image);
                                   // temp.add(URL);
                                   // DbUtil.insertImageDatatoDb(SearchItem,temp);

                                } }catch (JSONException e) {
                                Log.e(TAG, "Json parsing error: " + e.getMessage());
                            }


                        mAdapter.notifyDataSetChanged();

    }
},new ErrorListener(){

    @Override
    public void onErrorResponse(VolleyError error) {
        Log.e(TAG, "Error: " + error.getMessage());
//        final Image image=new Image();
//        List<String> temp = DbUtil.getImageDataFromDb(SearchItem);
//     for (int i=0; i<temp.size(); i++)
//         image.setFinalURl(temp.get(i));
//                     images.add(image);
             pDialog.hide();
    }

});
        AppController.getInstance().addToRequestQueue(jsonObjectRequest);

 }

    @Override
    protected void onPause() {
        super.onPause();
        pDialog.dismiss();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pDialog.dismiss();
    }
//    private boolean isNetworkAvailable() {
//        ConnectivityManager connectivityManager
//                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
//        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
//    }
}