package info.thecodingkeeda.glide.Database;

import java.util.ArrayList;
import java.util.List;


public class DbUtil {

private static AppDatabase mDb;
    public static void insertImageDatatoDb(String search, ArrayList<String> urls) {
        try {
            ImageCache imageCache = new ImageCache();
            imageCache.setString(search);
            imageCache.setImages(urls);
            mDb.imageCacheModel().insertImageData(imageCache);
        }
        catch (Exception e){
             e.getStackTrace();
        }
    }
    public static List<String> getImageDataFromDb(String mString) {


   List<String> imageCaches= mDb.imageCacheModel().getSpecificImageData(mString);

        return imageCaches;
    }
}
